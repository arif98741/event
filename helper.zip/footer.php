﻿				<footer>
				<p>&copy 2018 CGSA COLLEGE. All Rights Reserved | Developed by <a href="https://exploreit.com.bd/" target="_blank">explore IT</a></p>
				</footer>
				<!--footer section end-->
		 
				<script src="asset/js/jquery.nicescroll.js"></script>
				<script src="asset/js/scripts.js"></script>
				<!-- Bootstrap Core JavaScript -->
				<script src="asset/js/bootstrap.min.js"></script>
				<script src="asset/js/custom.js"></script>
				</body>
</html>				