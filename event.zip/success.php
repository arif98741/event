<?php include( 'header.php'); ?>

<!-- Full Width Column -->
<div class="container">
	<div class="row">
		
		<div class="col-md-12">
			<div style="background:#fff; padding:20px;box-shadow:0 1px 1px 0px #EFEFEF; class="table-container" width="100%">
				<?php if (isset($status)) {
					echo $status;
				} ?>
			</div>
			<br>
			
		</div>
		
		
	</div>
	
</div>
<!-- /.box-body -->
<?php include( 'footer.php'); ?>																																																		