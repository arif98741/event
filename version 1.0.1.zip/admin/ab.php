<?php 

echo strpos('ifle.tmp', '.tmt');