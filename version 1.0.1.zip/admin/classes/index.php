
<script>
    window.location = '../index.php';
</script>
